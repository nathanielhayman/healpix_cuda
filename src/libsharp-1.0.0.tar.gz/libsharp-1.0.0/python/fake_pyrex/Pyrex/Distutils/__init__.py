# work around broken setuptools monkey patching
